/*
 * File: Util.c
 * Driver Name: [[ Util ]]
 * SW Layer:   UTIL
 * Created on: Jun 28, 2020
 * Author:     Khaled Magdy
 * -------------------------------------------
 * For More Information, Tutorials, etc.
 * Visit Website: www.DeepBlueMbedded.com
 */

#include "Util.h"


